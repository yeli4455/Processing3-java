import java.util.Random;

class Restaurant{
  private String nameOfRestaurant;
  private String speciality;
  private int priceRating;
  private boolean willBeVisited;
  private int criticRating;
  
  public Restaurant(String name,String s,int pr){
    nameOfRestaurant=name;
    speciality=s;
    priceRating=pr;
    willBeVisited=false;
    Random rand=new Random();
    criticRating=rand.nextInt(5)+1;
  }
  
  public boolean getVisiting(){
    return willBeVisited;
  }
  
  public void toggleVisiting(){
    if (willBeVisited){
      willBeVisited=false;
    }else{
      willBeVisited=true;
    }
  }
  public String toString(){
    if(priceRating==1){
      return nameOfRestaurant+", "+speciality+", "+"£"+"\nRated ("+criticRating+"/5)";
    }else if (priceRating==2){
      return nameOfRestaurant+", "+speciality+", "+"££"+"\nRated ("+criticRating+"/5)";
    }else{
      return nameOfRestaurant+", "+speciality+", "+"£££"+"\nRated ("+criticRating+"/5)";
    }
  }
}
  
  
    
