import java.util.Scanner;
import java.util.ArrayList;
class RestaurantGuide{
  private ArrayList<Restaurant> restaurants;
  
  public RestaurantGuide(String fileName){
    restaurants=new ArrayList<Restaurant>();
    Scanner in;
    in = InputReader.getScanner(fileName);
    while (in.hasNext()) {
      String csv = in.nextLine();
      String[] data = csv.split(","); 
    }
    for (int i=0;i<data.length();i=i+3){
      restaurants.add(new Restaurant(data[i],data[i+1],Integer.parseIn(data[i+2])));
    }
  }
  public int listSize(){
    return restaurants.size();
  }
  
  public Restaurant getRestaurant(int index){
    return restaurants.get(index);
  }
  public void printVisiting(){
    for (int i=0; i<restaurants.size();i++){
      Restaurant restaurant=restaurants.get(i)
      if(restaurant.getVisiting()){
        System.out.println(restaurant.toString());
      }
    }
  }
}
  
  
